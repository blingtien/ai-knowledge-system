#!/usr/bin/env python3
"""
RAG Knowledge Management Web Interface
提供知识库管理和查询的Web界面，运行在端口4000
"""
import os
import json
import asyncio
import aiofiles
import hashlib
import uuid
from pathlib import Path
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import uvicorn
import aiohttp

# 应用配置
app = FastAPI(title="RAG Knowledge Management Web Interface", version="1.0.0")

# 配置目录
BASE_DIR = Path(__file__).parent
STATIC_DIR = BASE_DIR / "static"
UPLOADS_DIR = BASE_DIR / "uploads"
KNOWLEDGE_BASES_DIR = BASE_DIR / "knowledge_bases"

# 确保目录存在
for dir_path in [UPLOADS_DIR, KNOWLEDGE_BASES_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# RAG服务配置
RAG_SERVICE_URL = "http://localhost:8001"
RAG_HEALTH_URL = f"{RAG_SERVICE_URL}/health"
RAG_QUERY_URL = f"{RAG_SERVICE_URL}/api/query"
RAG_INSERT_URL = f"{RAG_SERVICE_URL}/api/insert"

# 挂载静态文件
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# 数据模型
class QueryRequest(BaseModel):
    query: str
    mode: str = "hybrid"
    
class QueryResponse(BaseModel):
    status: str
    result: str
    mode: str
    timestamp: datetime

class KnowledgeBase(BaseModel):
    name: str
    description: str = ""
    
class FileInfo(BaseModel):
    filename: str
    size: int
    upload_time: datetime
    status: str = "uploaded"  # uploaded, processing, completed, error
    progress: int = 0
    knowledge_base: str

# 全局状态管理
knowledge_bases = {}
file_status = {}

# 启动时加载已存在的知识库
def load_existing_knowledge_bases():
    """从文件系统加载已存在的知识库"""
    if KNOWLEDGE_BASES_DIR.exists():
        for kb_dir in KNOWLEDGE_BASES_DIR.iterdir():
            if kb_dir.is_dir():
                knowledge_bases[kb_dir.name] = {
                    "name": kb_dir.name,
                    "description": "",
                    "created_time": datetime.fromtimestamp(kb_dir.stat().st_ctime),
                    "file_count": len(list(kb_dir.glob("*"))),
                    "path": str(kb_dir)
                }
                print(f"📂 加载知识库: {kb_dir.name}")

def load_existing_files():
    """从上传目录加载已存在的文件"""
    if UPLOADS_DIR.exists():
        for file_path in UPLOADS_DIR.glob("*"):
            if file_path.is_file():
                # 解析文件名: "知识库_uuid.扩展名"
                filename = file_path.name
                if "_" in filename:
                    kb_name = filename.split("_")[0]
                    # 这里我们无法从安全文件名反推原始文件名
                    # 所以只记录基本信息，原始文件名设为安全文件名
                    file_info = {
                        "filename": filename,  # 将安全文件名作为显示名
                        "safe_filename": filename,
                        "size": file_path.stat().st_size,
                        "upload_time": datetime.fromtimestamp(file_path.stat().st_ctime),
                        "status": "uploaded",  # 重启后状态重置为uploaded
                        "progress": 0,
                        "knowledge_base": kb_name,
                        "file_path": str(file_path)
                    }
                    file_status[filename] = file_info
                    print(f"📄 加载文件: {filename}")

# 应用启动时执行
load_existing_knowledge_bases()
load_existing_files()

@app.get("/", response_class=HTMLResponse)
async def read_root():
    """返回主页面"""
    html_file = STATIC_DIR / "index.html"
    if html_file.exists():
        async with aiofiles.open(html_file, 'r', encoding='utf-8') as f:
            content = await f.read()
        return HTMLResponse(content=content)
    else:
        return HTMLResponse(content="""
        <html><body>
        <h1>RAG Knowledge Management System</h1>
        <p>静态文件未找到，请检查 static/index.html</p>
        </body></html>
        """)

@app.get("/health")
async def health_check():
    """健康检查，同时检查RAG服务状态"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(RAG_HEALTH_URL) as response:
                if response.status == 200:
                    rag_status = await response.json()
                    return {
                        "status": "healthy",
                        "service": "web-interface",
                        "port": 4000,
                        "rag_service": rag_status,
                        "knowledge_bases": len(knowledge_bases),
                        "total_files": len(file_status)
                    }
                else:
                    return {
                        "status": "degraded", 
                        "service": "web-interface",
                        "error": "RAG service unavailable"
                    }
    except Exception as e:
        return {
            "status": "error",
            "service": "web-interface", 
            "error": str(e)
        }

@app.get("/api/knowledge-bases")
async def list_knowledge_bases():
    """获取知识库列表"""
    return {"knowledge_bases": list(knowledge_bases.values())}

@app.post("/api/knowledge-bases")
async def create_knowledge_base(kb: KnowledgeBase):
    """创建新的知识库"""
    if kb.name in knowledge_bases:
        raise HTTPException(status_code=400, detail="Knowledge base already exists")
    
    # 创建知识库目录
    kb_dir = KNOWLEDGE_BASES_DIR / kb.name
    kb_dir.mkdir(exist_ok=True)
    
    knowledge_bases[kb.name] = {
        "name": kb.name,
        "description": kb.description,
        "created_time": datetime.now(),
        "file_count": 0,
        "path": str(kb_dir)
    }
    
    return {"status": "success", "message": f"Knowledge base '{kb.name}' created"}

@app.get("/api/files")
async def list_files(knowledge_base: Optional[str] = None):
    """获取文件列表"""
    if knowledge_base:
        filtered_files = {k: v for k, v in file_status.items() 
                         if v.get("knowledge_base") == knowledge_base}
        return {"files": list(filtered_files.values())}
    return {"files": list(file_status.values())}

@app.post("/api/upload")
async def upload_files(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    knowledge_base: str = Form(...)
):
    """上传文件到指定知识库"""
    print(f"📤 收到上传请求: 知识库={knowledge_base}, 文件数={len(files)}")
    
    if knowledge_base not in knowledge_bases:
        print(f"❌ 知识库不存在: {knowledge_base}")
        raise HTTPException(status_code=400, detail=f"知识库 '{knowledge_base}' 不存在，请先创建知识库")
    
    uploaded_files = []
    
    try:
        for file in files:
            print(f"📄 处理文件: {file.filename}")
            
            # 生成安全的文件名（避免文件名过长或包含特殊字符）
            file_ext = Path(file.filename).suffix
            # 使用UUID生成唯一文件名
            safe_filename = f"{knowledge_base}_{uuid.uuid4().hex[:8]}{file_ext}"
            file_path = UPLOADS_DIR / safe_filename
            
            # 保存文件
            async with aiofiles.open(file_path, 'wb') as f:
                content = await file.read()
                await f.write(content)
            
            # 记录文件状态
            file_info = {
                "filename": file.filename,  # 保持原始文件名用于显示
                "safe_filename": safe_filename,  # 保存的安全文件名
                "size": len(content),
                "upload_time": datetime.now(),
                "status": "uploaded",
                "progress": 0,
                "knowledge_base": knowledge_base,
                "file_path": str(file_path)
            }
            
            # 使用安全文件名作为键
            file_status[safe_filename] = file_info
            uploaded_files.append(file_info)
            print(f"✅ 文件上传成功: {file.filename}")
            
    except Exception as e:
        print(f"❌ 上传失败: {e}")
        raise HTTPException(status_code=500, detail=f"文件上传失败: {str(e)}")
    
    # 更新知识库文件计数
    knowledge_bases[knowledge_base]["file_count"] += len(uploaded_files)
    
    return {
        "status": "success", 
        "uploaded_files": len(uploaded_files),
        "files": uploaded_files
    }

@app.post("/api/parse")
async def start_parsing(
    background_tasks: BackgroundTasks,
    filename: str = Form(...),
    knowledge_base: str = Form(...)
):
    """开始解析指定文件"""
    print(f"🔍 收到解析请求: filename={filename}, kb={knowledge_base}")
    
    # 查找匹配的文件（通过原始文件名和知识库名）
    file_key = None
    for key, file_info in file_status.items():
        if (file_info.get("filename") == filename and 
            file_info.get("knowledge_base") == knowledge_base):
            file_key = key
            break
    
    if file_key is None:
        print(f"❌ 文件未找到: {filename}")
        print(f"📋 当前文件列表: {list(file_status.keys())}")
        raise HTTPException(status_code=404, detail=f"File not found: {filename}")
    
    # 启动后台解析任务
    background_tasks.add_task(process_file_parsing, file_key)
    
    # 更新状态
    file_status[file_key]["status"] = "processing"
    file_status[file_key]["progress"] = 0
    
    return {"status": "success", "message": f"Started parsing {filename}"}

async def process_file_parsing(file_key: str):
    """后台文件解析任务"""
    try:
        print(f"🔄 开始解析文件: {file_key}")
        file_info = file_status[file_key]
        file_path = file_info["file_path"]
        
        # 真实进度跟踪
        file_status[file_key]["progress"] = 10
        print(f"📊 进度更新: {file_key} -> 10% (开始读取文件)")
        
        # 读取文件内容
        try:
            # 尝试UTF-8编码
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
        except UnicodeDecodeError:
            # 如果UTF-8失败，尝试其他编码
            try:
                async with aiofiles.open(file_path, 'r', encoding='gbk') as f:
                    content = await f.read()
            except UnicodeDecodeError:
                # 最后尝试二进制读取
                async with aiofiles.open(file_path, 'rb') as f:
                    raw_content = await f.read()
                    content = raw_content.decode('utf-8', errors='ignore')
        
        file_status[file_key]["progress"] = 30
        print(f"📊 进度更新: {file_key} -> 30% (文件读取完成，内容长度: {len(content)} 字符)")
        
        file_status[file_key]["progress"] = 50
        print(f"📊 进度更新: {file_key} -> 50% (准备发送到RAG服务)")
        
        # 调用RAG服务插入文档
        file_status[file_key]["progress"] = 70
        print(f"📊 进度更新: {file_key} -> 70% (正在发送到RAG服务)")
        
        timeout = aiohttp.ClientTimeout(total=60)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            payload = {"text": content}
            async with session.post(RAG_INSERT_URL, json=payload) as response:
                if response.status == 200:
                    file_status[file_key]["progress"] = 90
                    print(f"📊 进度更新: {file_key} -> 90% (RAG服务处理完成)")
                    
                    file_status[file_key]["status"] = "completed"
                    file_status[file_key]["progress"] = 100
                    print(f"✅ 文件解析成功: {file_key} -> 100% (全部完成)")
                else:
                    error_text = await response.text()
                    print(f"❌ RAG插入失败: {response.status} - {error_text}")
                    file_status[file_key]["status"] = "error"
                    file_status[file_key]["progress"] = 0
                    file_status[file_key]["error"] = f"RAG服务错误: {error_text}"
                    
    except Exception as e:
        print(f"❌ 解析异常: {file_key} - {e}")
        file_status[file_key]["status"] = "error"
        file_status[file_key]["progress"] = 0
        file_status[file_key]["error"] = str(e)

@app.get("/api/files/{file_key}/status")
async def get_file_status(file_key: str):
    """获取文件解析状态"""
    print(f"🔍 查询文件状态: {file_key}")
    
    # 首先尝试直接匹配（安全文件名）
    if file_key in file_status:
        return file_status[file_key]
    
    # 如果直接匹配失败，尝试通过原始文件名匹配
    # file_key格式: "知识库名_原始文件名"
    if "_" in file_key:
        kb_name, original_filename = file_key.split("_", 1)
        for key, file_info in file_status.items():
            if (file_info.get("knowledge_base") == kb_name and 
                file_info.get("filename") == original_filename):
                print(f"📋 通过原始文件名找到: {key}")
                return file_info
    
    print(f"❌ 文件未找到: {file_key}")
    print(f"📋 当前文件列表: {list(file_status.keys())}")
    raise HTTPException(status_code=404, detail="File not found")

@app.post("/api/query")
async def query_knowledge_base(request: QueryRequest):
    """查询知识库"""
    try:
        # 设置60秒超时，因为LLM推理需要时间
        timeout = aiohttp.ClientTimeout(total=60)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            payload = {
                "query": request.query,
                "mode": request.mode
            }
            
            async with session.post(RAG_QUERY_URL, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    return QueryResponse(
                        status="success",
                        result=data["data"],
                        mode=request.mode,
                        timestamp=datetime.now()
                    )
                else:
                    error_text = await response.text()
                    raise HTTPException(status_code=response.status, detail=error_text)
                    
    except aiohttp.ClientError as e:
        raise HTTPException(status_code=503, detail=f"RAG service unavailable: {str(e)}")

@app.post("/api/query-profile")
async def query_knowledge_base_with_profiling(request: QueryRequest):
    """带性能分析的查询知识库"""
    try:
        # 设置60秒超时，因为LLM推理需要时间
        timeout = aiohttp.ClientTimeout(total=60)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            payload = {
                "query": request.query,
                "mode": request.mode
            }
            
            # 使用RAG服务的性能分析接口
            async with session.post(f"{RAG_SERVICE_URL}/api/query-profile", json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "status": "success",
                        "data": data["data"],
                        "mode": request.mode,
                        "timestamp": datetime.now().isoformat(),
                        "performance": data["performance"]
                    }
                else:
                    error_text = await response.text()
                    raise HTTPException(status_code=response.status, detail=error_text)
                    
    except aiohttp.ClientError as e:
        raise HTTPException(status_code=503, detail=f"RAG service unavailable: {str(e)}")

if __name__ == "__main__":
    print("🚀 启动RAG Knowledge Management Web Interface")
    print("📍 访问地址: http://localhost:4000")
    print("🔗 RAG服务: http://localhost:8001")
    uvicorn.run(app, host="0.0.0.0", port=4000)