const { createApp } = Vue;
const { ElMessage, ElMessageBox } = ElementPlus;

createApp({
    data() {
        return {
            // 系统状态
            systemStatus: {
                type: 'info',
                text: '检查中...'
            },
            
            // 导航
            activeTab: 'knowledge-base',
            
            // 知识库管理
            knowledgeBases: [],
            createKBDialog: false,
            newKB: {
                name: '',
                description: ''
            },
            
            // 文件上传
            uploadForm: {
                knowledgeBase: ''
            },
            fileList: [],
            uploading: false,
            
            // 文件列表
            files: [],
            selectedKB: '',
            
            // 查询
            queryForm: {
                query: '',
                mode: 'hybrid'
            },
            queryResult: null,
            queryHistory: [],
            querying: false,
            queryStatus: ''
        };
    },
    
    mounted() {
        this.init();
    },
    
    methods: {
        async init() {
            await this.checkSystemStatus();
            await this.loadKnowledgeBases();
            await this.loadFiles();
            this.loadQueryHistory();
        },
        
        // 系统状态检查
        async checkSystemStatus() {
            try {
                const response = await fetch('/health');
                const data = await response.json();
                
                if (data.status === 'healthy') {
                    this.systemStatus = {
                        type: 'success',
                        text: '系统正常'
                    };
                } else {
                    this.systemStatus = {
                        type: 'warning',
                        text: '系统异常'
                    };
                }
            } catch (error) {
                this.systemStatus = {
                    type: 'danger',
                    text: '连接失败'
                };
            }
        },
        
        // 菜单选择
        handleMenuSelect(index) {
            this.activeTab = index;
            if (index === 'file-list') {
                this.loadFiles();
            }
        },
        
        // 知识库管理
        async loadKnowledgeBases() {
            try {
                const response = await fetch('/api/knowledge-bases');
                const data = await response.json();
                this.knowledgeBases = data.knowledge_bases;
            } catch (error) {
                ElMessage.error('加载知识库列表失败');
            }
        },
        
        showCreateKBDialog() {
            this.createKBDialog = true;
            this.newKB = { name: '', description: '' };
        },
        
        async createKnowledgeBase() {
            if (!this.newKB.name.trim()) {
                ElMessage.warning('请输入知识库名称');
                return;
            }
            
            try {
                const response = await fetch('/api/knowledge-bases', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.newKB)
                });
                
                if (response.ok) {
                    ElMessage.success('知识库创建成功');
                    this.createKBDialog = false;
                    await this.loadKnowledgeBases();
                } else {
                    const error = await response.json();
                    ElMessage.error(error.detail || '创建失败');
                }
            } catch (error) {
                ElMessage.error('创建知识库失败');
            }
        },
        
        // 文件上传
        handleFileChange(file, fileList) {
            this.fileList = fileList;
        },
        
        clearFiles() {
            this.fileList = [];
            this.$refs.uploadRef.clearFiles();
        },
        
        async uploadFiles() {
            if (!this.uploadForm.knowledgeBase) {
                ElMessage.warning('请选择知识库');
                return;
            }
            
            if (this.fileList.length === 0) {
                ElMessage.warning('请选择文件');
                return;
            }
            
            this.uploading = true;
            
            try {
                const formData = new FormData();
                formData.append('knowledge_base', this.uploadForm.knowledgeBase);
                
                this.fileList.forEach(file => {
                    formData.append('files', file.raw);
                });
                
                const response = await fetch('/api/upload', {
                    method: 'POST',
                    body: formData
                });
                
                if (response.ok) {
                    const data = await response.json();
                    ElMessage.success(`成功上传 ${data.uploaded_files} 个文件`);
                    this.clearFiles();
                    await this.loadFiles();
                    
                    // 切换到文件列表页面
                    this.activeTab = 'file-list';
                } else {
                    const error = await response.json();
                    ElMessage.error(error.detail || '上传失败');
                }
            } catch (error) {
                ElMessage.error('上传文件失败');
            } finally {
                this.uploading = false;
            }
        },
        
        // 文件列表
        async loadFiles() {
            try {
                const url = this.selectedKB ? 
                    `/api/files?knowledge_base=${this.selectedKB}` : 
                    '/api/files';
                    
                const response = await fetch(url);
                const data = await response.json();
                this.files = data.files;
            } catch (error) {
                ElMessage.error('加载文件列表失败');
            }
        },
        
        async startParsing(file) {
            try {
                const formData = new FormData();
                formData.append('filename', file.filename);
                formData.append('knowledge_base', file.knowledge_base);
                
                const response = await fetch('/api/parse', {
                    method: 'POST',
                    body: formData
                });
                
                if (response.ok) {
                    ElMessage.success('开始解析文件');
                    
                    // 启动进度监控
                    this.monitorProgress(file);
                } else {
                    const error = await response.json();
                    ElMessage.error(error.detail || '启动解析失败');
                }
            } catch (error) {
                ElMessage.error('启动解析失败');
            }
        },
        
        async monitorProgress(file) {
            const fileKey = `${file.knowledge_base}_${file.filename}`;
            
            const checkProgress = async () => {
                try {
                    const response = await fetch(`/api/files/${fileKey}/status`);
                    const data = await response.json();
                    
                    // 更新本地文件状态
                    const index = this.files.findIndex(f => 
                        f.knowledge_base === file.knowledge_base && 
                        f.filename === file.filename
                    );
                    
                    if (index !== -1) {
                        this.files[index] = { ...this.files[index], ...data };
                    }
                    
                    // 如果还在处理中，继续监控
                    if (data.status === 'processing') {
                        setTimeout(checkProgress, 2000);
                    } else if (data.status === 'completed') {
                        ElMessage.success(`文件 ${file.filename} 解析完成`);
                    } else if (data.status === 'error') {
                        ElMessage.error(`文件 ${file.filename} 解析失败`);
                    }
                } catch (error) {
                    console.error('监控进度失败:', error);
                }
            };
            
            setTimeout(checkProgress, 1000);
        },
        
        // 查询功能 - 简化版本
        async performQuery() {
            if (!this.queryForm.query.trim()) {
                ElMessage.warning('请输入查询问题');
                return;
            }
            
            this.querying = true;
            this.queryStatus = '正在查询...';
            
            try {
                const response = await fetch('/api/query', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.queryForm)
                });
                
                if (response.ok) {
                    const data = await response.json();
                    this.queryResult = data;
                    this.queryStatus = '查询完成';
                    
                    // 添加到历史记录
                    this.queryHistory.unshift({
                        query: this.queryForm.query,
                        result: data.result,
                        mode: data.mode,
                        timestamp: new Date().toISOString()
                    });
                    
                    // 限制历史记录数量
                    if (this.queryHistory.length > 10) {
                        this.queryHistory = this.queryHistory.slice(0, 10);
                    }
                    
                    this.saveQueryHistory();
                    ElMessage.success('查询完成');
                    
                } else {
                    this.queryStatus = '查询失败';
                    ElMessage.error('查询失败');
                }
            } catch (error) {
                console.error('查询错误:', error);
                this.queryStatus = '查询异常';
                ElMessage.error('查询失败: ' + error.message);
            } finally {
                this.querying = false;
                setTimeout(() => {
                    this.queryStatus = '';
                }, 3000);
            }
        },
        
        // 获取查询状态更新
        getQueryStatusUpdates(mode) {
            if (mode === 'naive') {
                return [
                    { status: '正在预处理查询请求...' },
                    { status: '正在计算文本向量...' },
                    { status: '正在搜索相关文档...' },
                    { status: '正在整理查询结果...' }
                ];
            } else if (mode === 'local') {
                return [
                    { status: '正在预处理查询请求...' },
                    { status: '正在计算文本向量...' },
                    { status: '正在分析局部知识图谱...' },
                    { status: '正在发送请求到LLM...' },
                    { status: '正在等待LLM深度分析...' },
                    { status: '正在遍历关联知识节点...' },
                    { status: '正在生成最终答案...' }
                ];
            } else if (mode === 'global') {
                return [
                    { status: '正在预处理查询请求...' },
                    { status: '正在计算文本向量...' },
                    { status: '正在检索全局知识图谱...' },
                    { status: '正在发送请求到LLM...' },
                    { status: '正在等待LLM全局分析...' },
                    { status: '正在整合多维度信息并生成答案...' }
                ];
            } else { // hybrid
                return [
                    { status: '正在预处理查询请求...' },
                    { status: '正在计算文本向量...' },
                    { status: '正在执行相似度检索...' },
                    { status: '正在分析知识图谱结构...' },
                    { status: '正在发送请求到LLM...' },
                    { status: '正在等待LLM智能推理...' },
                    { status: '正在融合检索和推理结果...' }
                ];
            }
        },
        
        // 模拟查询进度
        async simulateQueryProgress(statusUpdates) {
            for (let i = 0; i < statusUpdates.length; i++) {
                if (!this.querying) break;
                
                const update = statusUpdates[i];
                this.queryStatus = update.status;
                
                // 根据查询模式调整延迟
                const delay = this.getProgressDelay(this.queryForm.mode);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        },
        
        // 获取进度延迟
        getProgressDelay(mode) {
            const delays = {
                'naive': 200,    // 快速模式
                'global': 800,   // 中等延迟
                'hybrid': 1000,  // 较慢
                'local': 1500    // 最慢
            };
            return delays[mode] || 1000;
        },
        
        // 获取模式显示名称
        getModeDisplayName(mode) {
            const names = {
                'naive': '快速检索',
                'local': '深度分析',
                'global': '全局分析', 
                'hybrid': '智能融合'
            };
            return names[mode] || mode;
        },
        
        // 获取模式描述
        getModeDescription(mode) {
            const descriptions = {
                'naive': '基于向量相似度的快速检索，适合简单问答',
                'local': '深度分析局部知识图谱，适合复杂推理任务',
                'global': '全局知识图谱分析，适合宏观概览问题',
                'hybrid': '融合多种检索策略，平衡效果与效率'
            };
            return descriptions[mode] || '未知模式';
        },
        
        // 获取预计时间
        getEstimatedTime(mode) {
            const times = {
                'naive': '约1秒',
                'local': '约12秒',
                'global': '约6秒',
                'hybrid': '约9秒'
            };
            return times[mode] || '计算中...';
        },
        
        clearQuery() {
            this.queryForm.query = '';
            this.queryResult = null;
            this.queryHistory = [];
            this.queryStatus = '';
            // 清空本地存储的历史记录
            localStorage.removeItem('queryHistory');
            ElMessage.success('已清空查询内容和历史记录');
        },
        
        // 本地存储
        saveQueryHistory() {
            localStorage.setItem('queryHistory', JSON.stringify(this.queryHistory));
        },
        
        loadQueryHistory() {
            const saved = localStorage.getItem('queryHistory');
            if (saved) {
                this.queryHistory = JSON.parse(saved);
            }
        },
        
        // 工具函数
        formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleString('zh-CN');
        },
        
        formatFileSize(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        },
        
        getStatusType(status) {
            const statusMap = {
                'uploaded': 'info',
                'processing': 'warning',
                'completed': 'success',
                'error': 'danger'
            };
            return statusMap[status] || 'info';
        },
        
        getStatusText(status) {
            const statusMap = {
                'uploaded': '已上传',
                'processing': '解析中',
                'completed': '已完成',
                'error': '解析失败'
            };
            return statusMap[status] || status;
        },
        
        formatResult(text) {
            // 简单的格式化处理
            return text.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        }
    }
}).use(ElementPlus).mount('#app');